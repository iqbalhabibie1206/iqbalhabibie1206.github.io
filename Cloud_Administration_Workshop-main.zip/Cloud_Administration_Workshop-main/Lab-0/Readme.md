# PREPARATION

1. Download and Install Putty for Windows (Putty.exe) </br>
To download: https://www.putty.org/. </br>
To install: https://www.ssh.com/ssh/putty/windows/install

2. Download Workshop Material from this page </br>
https://github.com/tripplea-sg/Cloud_Administration_Workshop/blob/main/Lab-0/20201112-MySQL%20Enterprise%20Edition%201.pdf. </br>
https://github.com/tripplea-sg/Cloud_Administration_Workshop/blob/main/Lab-0/20201112-MySQL%20Enterprise%20Edition%202.pdf </br>

3. Download public key (id_rsa.pub) to create VM on Oracle Cloud for this workshop
4. Download private key (workshop.ppk) to connect using Putty. Save the file on D:\temp\
5. Download private key (id_rsa) to local drive, just in case.
